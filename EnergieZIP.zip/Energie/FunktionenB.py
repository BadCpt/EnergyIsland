import pygame.mask
import FunktionenA
import pygame.midi
import pygame.mouse
from FunktionenA import *
from CundF import *
from Classes import *
mps = 0

"""In dieser Datei werden alle Programmspezifischen Funktionen festgelegt. Erklärunen in 'main.py' oder ggf. hier"""

def setstartpixels():
    pixels[739] = Gras()
    pixels[740] = Gras()
    pixels[741] = Gras()
    pixels[742] = Gras()
    pixels[779] = Gras()
    pixels[780] = Gras()
    pixels[781] = Gras()
    pixels[782] = Gras()
    pixels[819] = Gras()
    pixels[820] = Gras()
    pixels[821] = Gras()
    pixels[822] = Gras()
    pixels[859] = Gras()
    pixels[860] = Gras()
    pixels[861] = Gras()
    pixels[862] = Gras()
def createforest():
    pixels[0] = Wald1
    for i in range(1,1600):
        pW = 0.5
        if pixels[i-1] == Wald1: pW += 0.2
        elif pixels[i-1] == Wald2: pW -= 0.2
        if pixels[i-40] == Wald1: pW += 0.2
        elif pixels[i-40] == Wald2: pW -= 0.2
        if random.random() > pW: pixels[i] = Wald2
        else: pixels[i] = Wald1
def choose_item():
    init_item(Gras, 1)
    init_item(PowerBoost, 1)
    init_item(Windrad, 2)
    init_item(Solar, 2)
    init_item(Biogasanlage, 2)
    init_item(Wasserkraftwerk, 2)
    init_item(Kohle, 2)
    init_item(Atom, 2)
    init_item(Antimateriekraftwerk, 2)
    init_item(SchwarzesLoch, 2)
    init_item(Dynamo, 3)
    init_item(Generator1, 3)
    init_item(Generator2, 3)
    init_item(Generator3, 3)
    init_item(Turbine1, 3)
    init_item(Turbine2, 3)
    init_item(Turbine3, 3)
    init_item(HyperTurbine, 3)
    init_item(Stromzaehler, 4)
    init_item(Haus1, 4)
    init_item(Haus2, 4)
    init_item(Haus3, 4)
    init_item(Fabrik1, 4)
    init_item(Fabrik2, 4)
    init_item(Fabrik3, 4)
    init_item(Universalwerk, 4)
    FunktionenA.itemcnt = 1
def set_item():
    if type(click("get")) == Gras and not Game.chosen_item == Gras:
        item = Game.chosen_item
        if Game.money >= item.preis:
            pixels[click()] = item()
            Game.money -= item.preis

    elif (click("get") == Wald1 or click("get") == Wald2) and Game.chosen_item == Gras and Game.money >= Gras.preis and um(click()).count(Wald1)+um(click()).count(Wald2)+um(click()).count(None) != 4:
            if random.random() >= Einstellungen.Steine:pixels[click()] = Gras()
            else: pixels[click()] = Stein()
            Game.money -= Gras.preis
            Gras.preis *= Einstellungen.Gplus
            Gras.preis = round(Gras.preis,1)
def sell_item():
    x,y = pygame.mouse.get_pos()
    if pygame.mouse.get_pressed(3)[2]:
        if pixels[mappos((x,y))].vkpreis is not None and Game.money >= (pixels[mappos((x,y))].vkpreis * -1):
            Game.money += pixels[mappos((x,y))].vkpreis
            pixels[mappos((x, y))] = Gras()
def update_animations():
    j = 0
    for i in pixels:
        if i.typ == 'power' or i.typ == 'PtE' or i.typ == 'boost' or type(i) == Universalwerk:
            if time.time() - i.lasttime >= i.animation_del:i.animationpart += 1; i.lasttime = time.time()
            i.pic = pygame.image.load(i.pics[i.animationpart%len(i.pics)])
        if i.typ == 'expl':
            bild = f'expl{i.state}.png'
            i.pic = pygame.image.load(bild)
            if time.time() - i.lasttime >= 0.05:i.state += 1; i.lasttime = time.time()
            if i.state >= 18: pixels[j] = Geroell(i.preis)
        if i.typ == 'geroell' and time.time() - i.starttime >= 15: pixels[j] = Stein

        j += 1
def extend_expl():
    j = 0
    gbde = ['power', 'PtE', 'EtM','boost']
    for i in pixels:
        if i.typ == 'expl' and i.updated == False:
            if uber(j, 'get').typ in gbde and random.random() <= i.expwr: uber(j, Explosion(uber(j, 'get').expwr, uber(j, 'get').preis))
            if unter(j, 'get').typ in gbde and random.random() <= i.expwr: unter(j, Explosion(unter(j, 'get').expwr, unter(j, 'get').preis))
            if links(j, 'get').typ in gbde and random.random() <= i.expwr: links(j, Explosion(links(j, 'get').expwr, links(j, 'get').preis))
            if rechts(j, 'get').typ in gbde and random.random() <= i.expwr: rechts(j, Explosion(rechts(j, 'get').expwr, rechts(j, 'get').preis))
            if uber(j, 'get').typ in ['blockade', 'geroell'] and random.random() <= i.expwr/10: uber(j, Explosion(uber(j, 'get').expwr, uber(j, 'get').preis))
            if unter(j, 'get').typ in ['blockade', 'geroell'] and random.random() <= i.expwr/10: unter(j, Explosion(unter(j, 'get').expwr, unter(j, 'get').preis))
            if links(j, 'get').typ in ['blockade', 'geroell'] and random.random() <= i.expwr/10: links(j, Explosion(links(j, 'get').expwr, links(j, 'get').preis))
            if rechts(j, 'get').typ in ['blockade', 'geroell'] and random.random() <= i.expwr/10: rechts(j, Explosion(rechts(j, 'get').expwr, rechts(j, 'get').preis))
        i.updated = True
        j += 1
def blit_item():
    j = 0
    for i in pixels:

        screen.blit(i.pic, (mappos(j)))
        if i.typ == "power":
            xpos,ypos = mappos(j)
            pygame.draw.line(screen, (0,0,0), (xpos, ypos+18), (xpos+(i.leben/type(i).leben)*20, ypos+18), Einstellungen.Dicke)
        elif (i.typ == "EtM" or i.typ == "PtE") and i.heat != 0:
            xpos, ypos = mappos(j)
            pygame.draw.line(screen, (255,0,0), (xpos, ypos + 18),(xpos + (i.heat / type(i).maxheat) * 20, ypos + 18), Einstellungen.Dicke)
        j += 1
def update_buildings():
    global mps
    Game.tick = time.time()
    if Game.old_tick <= Game.tick - 1/Einstellungen.TpS:
        Game.old_tick = Game.tick
        powerZUpte()
        pteZUetm()
        etmZUmoney()
        for j in range(len(pixels)):
            if pixels[j].typ == "power":
                pixels[j].leben -= 1
                if pixels[j].leben == 0:
                    if Game.money >= pixels[j].preis and Einstellungen.AutoReplace:
                        item = type(pixels[j])
                        pixels[j] = item()
                        Game.money -= pixels[j].preis
                    else: pixels[j] = Gras()
    infotext.render_to(screen, (60, 40), "+ " + str(mps) + " /s", gelb())
def set_mousetext():
    x,y = pygame.mouse.get_pos()
    if pixels[mappos((x,y))].typ == "power":
        mausfont_text1 = f"produziert: {pixels[mappos((x, y))].power} Energie"
        mausfont_text2 = "Leben: " + str(pixels[mappos((x,y))].leben) + "/" + str(type(pixels[mappos((x,y))]).leben)
    elif pixels[mappos((x,y))].typ == "PtE":
        obj = pixels[mappos((x,y))]
        mausfont_text1 = "Konvertiert " + str(obj.lastconvert) + "/" + str(type(obj).maxconvert) + "Energie"
        mausfont_text2 = "Überschuss: " + str(obj.heat) + "/" + str(type(obj).maxheat)
    elif pixels[mappos((x,y))].typ == "EtM":
        obj = pixels[mappos((x,y))]
        mausfont_text1 = "Konvertiert " + str(obj.lastconvert) + "/" + str(type(obj).maxconvert) + " Strom"
        mausfont_text2 = "Überschuss: " + str(obj.heat) + "/" + str(type(obj).maxheat)
    elif pixels[mappos((x,y))].typ == "untergrund":
        mausfont_text1 = "Hier können Gebäude gebaut werden."
        mausfont_text2 = None
    elif pixels[mappos((x,y))].typ == "blockade":
        mausfont_text1 = "Hier können keine Gebäude gebaut werden."
        mausfont_text2 = None
    elif pixels[mappos((x,y))].typ == "boost":
        mausfont_text1 = "Verbessert Produzenten um 10%."
        mausfont_text2 = None
    elif pixels[mappos((x,y))].typ == "expl":
        mausfont_text1 = "Kaboom?"
        mausfont_text2 = "Yes Rico, Kaboom!"
    elif pixels[mappos((x,y))].typ == "geroell":
        mausfont_text1 = "Verkaufen kostet 1/10 des normalen Preises."
        mausfont_text2 = 'Verkaufen: ' + str(pixels[mappos((x,y))].vkpreis) + "$"

    elif Einstellungen.Design == 2: mausfont_text1 = "Vergrößere zunächst die Insel"; mausfont_text2 = None
    else: mausfont_text1 = "Fälle zunächst den Baum."; mausfont_text2 = None

    if x >= 400:
        if pixels[mappos((x,y))].typ != 'expl':
            try: textmitbg(mausfont,(75,75,75),str(type(pixels[mappos((x,y))]))[16:-2],gelb(),(x+15,y))
            except:textmitbg(mausfont,(75,75,75),str(pixels[mappos((x,y))])[16:-2],gelb(),(x+15,y))
        textmitbg(mausfont, (75,75,75), mausfont_text1, gelb(), (x + 15, y+10))
        if mausfont_text2: textmitbg(mausfont,(75,75,75),mausfont_text2,gelb(),(x+15, y+20))
        pygame.draw.rect(screen, Einstellungen.RFarbe, pygame.Rect((mappos(mappos(pygame.mouse.get_pos()))), (20, 20)),
                         Einstellungen.RBreite)
def set_item_money_text():
    money = f"Geld: {round(Game.money, 2)} $"
    font.render_to(screen, (5,10), str(money), (weis()))
    infotext.render_to(screen, (5, 780), "Item: " + str(Game.chosen_item)[16:-2], weis())

def powerZUpte():
    for i in range(len(pixels)):
        if pixels[i].typ == "power":
            a = um(i)
            buildingsaround = 0
            powerperbuilding = 0
            power = pixels[i].power
            for j in a:
                if j.typ == "PtE": buildingsaround += 1
                elif j.typ == 'boost': power *= 1.1
            if buildingsaround != 0:  powerperbuilding = power / buildingsaround
            else:                     pixels[i] = Explosion(pixels[i].expwr, pixels[i].preis)
            if links(i, "get").typ == "PtE": pixels[i-1].convert  += powerperbuilding; pixels[i-1].convert  = round(pixels[i-1].convert, 3)
            if rechts(i,"get").typ == "PtE": pixels[i+1].convert  += powerperbuilding; pixels[i+1].convert  = round(pixels[i+1].convert, 3)
            if uber(i,  "get").typ == "PtE": pixels[i-40].convert += powerperbuilding; pixels[i-40].convert = round(pixels[i-40].convert, 3)
            if unter(i, "get").typ == "PtE": pixels[i+40].convert += powerperbuilding; pixels[i+40].convert = round(pixels[i+40].convert, 3);
# übergabe von Powergebäuden (typ = power) zu Umwandlern (typ = pte)
def pteZUetm():
    for i in range(len(pixels)):
        if pixels[i].typ == "PtE":
            a = um(i)
            b = 0
            for j in range(len(a)):
                if a[j].typ == "EtM": b += 1
            if b == 0:
                pixels[i].heat += pixels[i].convert
                pixels[i].convert = 0
            else:
                pixels[i].convert += pixels[i].heat
                pixels[i].heat = pixels[i].convert - pixels[i].maxconvert
                if pixels[i].heat < 0: pixels[i].heat = 0

                if pixels[i].convert > pixels[i].maxconvert: pixels[i].convert = pixels[i].maxconvert
                pixels[i].heat = round(pixels[i].heat, 3)
                pixels[i].convert = round(pixels[i].convert, 3)
                pixels[i].lastconvert = pixels[i].convert

                if pixels[i].typ == "PtE":
                    b = pixels[i].convert/b
                    if links(i,"get").typ=="EtM":pixels[i-1].convert +=b;pixels[i-1].convert=round(pixels[i-1].convert,3)
                    if rechts(i,"get").typ=="EtM":pixels[i+1].convert +=b;pixels[i+1].convert=round(pixels[i+1].convert,3)
                    if uber(i,"get").typ=="EtM":pixels[i-40].convert+=b;pixels[i-40].convert=round(pixels[i-40].convert,3)
                    if unter(i,"get").typ=="EtM":pixels[i+40].convert+=b;pixels[i+40].convert=round(pixels[i+40].convert,3)
                pixels[i].convert = 0
            destroy(i)
# übergabe von Umwandlern (typ = pte) zu Verbrauchern (typ = etm)
def etmZUmoney():
    global mps
    i = 0
    mps = 0
    while i < len(pixels):
        if pixels[i].typ == "EtM":
            pixels[i].convert += pixels[i].heat
            pixels[i].heat = pixels[i].convert - pixels[i].maxconvert
            if pixels[i].heat < 0: pixels[i].heat = 0
            if pixels[i].convert > pixels[i].maxconvert: pixels[i].convert = pixels[i].maxconvert
            pixels[i].heat = round(pixels[i].heat, 3)
            pixels[i].convert = round(pixels[i].convert, 3)
            destroy(i)
            try: Game.money += pixels[i].convert; mps += pixels[i].convert; pixels[i].lastconvert = pixels[i].convert; pixels[i].convert = 0
            except: pass
        i += 1
# übergabe von Verbrauchern (typ = etm) zu Geld
