import random           # random-modul einbinden
from Classes import *   # Classes einbinden
from CundF import *     # CundF einbinden

"""Hier werden die grundlegenden, ggf. auf das Programm abgestimmten Funktionen festgelegt."""

screen = pygame.display.set_mode([1200,800])    # festlegen des Bildschirms
starttime = time.time()                         # festlegen der Startzeit
pixels = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
# Liste, in der die einzelnen Gebäude gespeichert werden

scroll = 0                                      # festlegen der scroll-Variable für den Auswahlstreifen
itemcnt = 1                                     # festlegen einer Zählvariable für das Darstellen des Auswahlstreifens

# Funktion zur Abfrafe eines Mausklicks
def click(obj=None):
    pygame.event.get()
    x,y = pygame.mouse.get_pos()
    if obj == "get":
        if pygame.mouse.get_pressed(3)[0] and x >= 400: return pixels[mappos((x, y))]
    elif obj is None:
        if pygame.mouse.get_pressed(3)[0] and x >= 400: return mappos((x,y))
        else: return None
    elif type(obj) == tuple:
        mousepos = pygame.Rect(x, y, 1, 1)
        (obx,oby) = obj
        pos = pygame.Rect(obx, oby, 20, 20)
        if mousepos.colliderect(pos) and pygame.mouse.get_pressed(3)[0]:
            return True
        else:
            return False
# Funktion zum umrechnen von einer Zahl (v.a. in Pixel list) in Koordinaten und umgekehrt
def mappos(posi):
    if type(posi) == tuple:
        x,y = posi
        x -= 400
        x = x//20
        y = y//20
        return int(y*40+x)
    elif type(posi) == int:
        x = (posi % 40 * 20)+400
        y = (posi // 40) * 20
        screenpos = x,y
        return screenpos
# abfrage zum Status einer Taste
def taste(button):
    pygame.event.get()
    if pygame.key.get_pressed()[pygame.key.key_code(button)]: time.sleep(0.1); return True
    else: return False
# funktionen zur abfrage undneubestimmung umliegender Felder
def uber(pos, item):
    if item == "get":
        if type(pos) == int and pos >= 40:      return pixels[pos - 40]
        elif type(pos) == tuple and pos >= 40:  (x,y) = pos; return pixels[mappos((x, y - 1))]
        else:                                   return Wald2
    else:
        if type(pos) == int and pos >= 40:      pixels[pos - 40] = item
        elif type(pos) == int and pos >= 40:    (x, y) = pos; pixels[mappos((x, y - 1))] = item
        else:                                   return None
def unter(pos, item):
    if item == "get":
        if type(pos) == int and pos <= 1559:      return pixels[pos + 40]
        elif type(pos) == tuple and pos <= 1559:  (x,y) = pos; return pixels[mappos((x, y + 1))]
        else:                                     return Wald2
    else:
        if type(pos) == int and pos <= 1559:      pixels[pos + 40] = item
        elif type(pos) == int and pos <= 1559:    (x, y) = pos; pixels[mappos((x, y + 1))] = item
        else: return None
def links(pos,item):
    if item == "get":
        if type(pos) == int and pos >= 1:      return pixels[pos - 1]
        elif type(pos) == tuple and pos >= 1:  (x,y) = pos; return pixels[mappos((x - 1, y))]
        else:                                   return Wald2
    else:
        if type(pos) == int and pos >= 1:      pixels[pos - 1] = item
        elif type(pos) == int and pos >= 1:    (x, y) = pos; pixels[mappos((x - 1, y))] = item
def rechts(pos,item):
    if item == "get":
        if type(pos) == int and pos <= 1598:      return pixels[pos + 1]
        elif type(pos) == tuple and pos <= 1598:  (x, y) = pos; return pixels[mappos((x + 1, y))]
        else: return Wald2
    else:
        if type(pos) == int and pos <= 1598: pixels[pos + 1] = item
        elif type(pos) == int and pos <= 1598: (x, y) = pos; pixels[mappos((x + 1, y))] = item
        else: return False
def um(pos):
    r = [None,None,None,None]
    r[1] = rechts(pos,"get")
    r[3] = links(pos,"get")
    r[0] = uber(pos,"get")
    r[2] = unter(pos,"get")
    return r
# Funktion zu Berechnung der Position eines Gebäudes aud dem Auswahlstreifen
def chooseitemposi(group, add=0):
    global scroll,itemcnt
    return itemcnt*80+(group-1)*30+add+scroll
# Gebäude in Spiel importieren und auf Auswahlstreifen darstellen
def init_item(item, group):
    global itemcnt

    if taste(item.shortcut): Game.chosen_item = item
    if pygame.mouse.get_pressed(3)[1] and not pixels[mappos(pygame.mouse.get_pos())].typ in ['Wald', 'blockade', 'geroell']: Game.chosen_item = type(pixels[mappos(pygame.mouse.get_pos())])
    if 50 <= chooseitemposi(group, 15) <= 750:
        (x, y) = pygame.mouse.get_pos()
        if 5 <= x <= 350:
            if chooseitemposi(group) <= y <= chooseitemposi(group, 60):
                pygame.draw.rect(screen, (255,255,255), pygame.Rect(2, chooseitemposi(group, -5), 300, 70), 2)
        if pygame.mouse.get_pressed(3)[0]:
            if 5 <= x <= 350 and chooseitemposi(group) <= y <= chooseitemposi(group, 60):Game.chosen_item = item

        if item.typ == "power":text2 = f"Produziert: {item.power} power"
        elif item.typ == "untergrund":text2 = "Untergrund für Gebäude"
        elif item.typ == "PtE":text2 = f"Konvertiert: {item.maxconvert} power zu Strom"
        elif item.typ == "EtM":text2 = f"Konvertiert: {item.maxconvert} Strom zu €"
        else: text2 = None

        text0 = str(item)[16:-2]
        text1 = f"Preis: {item.preis} $"
        try: text3 = "Leben: " + str(item.leben)
        except: text3 = None
        if item.preis > Game.money: farbe = (255,0,0)
        else: farbe = gelb()
        screen.blit(pygame.transform.scale(item.pic, (60, 60)), (5, chooseitemposi(group)))
        infotextb.render_to(screen, (80, chooseitemposi(group)), text0, (255,255,255))
        infotext.render_to(screen, (80, chooseitemposi(group, 20)), text1, farbe)
        if text2 is not None:infotext.render_to(screen, (80, chooseitemposi(group, 35)), text2, weis())
        if text3 is not None:infotext.render_to(screen, (80, chooseitemposi(group, 50)), text3, weis())
        infotext.render_to(screen, (285, chooseitemposi(group,5)), item.shortcut, (255,255,255))

        if item == Game.chosen_item: pygame.draw.rect(screen,(255,0,0),pygame.Rect(2,chooseitemposi(group,-5),300,70),2)
    itemcnt += 1
# Explosion bei Überhitzung
def destroy(i):
    if pixels[i].heat > pixels[i].maxheat: pixels[i] = Explosion(pixels[i].expwr, pixels[i].preis)
# Text mit Hintergrund darstellen
def textmitbg(schriftart, SFarbe, text, BgFarbe,pos):
    testtext = pygame.freetype.Font.render_to(schriftart, screen, pos, str(text))
    pygame.draw.rect(screen, BgFarbe, pygame.Rect(pos, testtext.size))
    pygame.freetype.Font.render_to(schriftart, screen, pos, str(text), SFarbe)