"""Hier sind Abkürzungen für Farben und Schriftarten"""

import pygame.freetype   # Schriftarten einbinden
pygame.init()            # pygame initialisieren

def weis(): return 255,255,255   # festlegen der Farbe Weis
def gelb(): return 255,255,0     # festlegen der Farbe Gelb


font = pygame.freetype.SysFont('arial.ttf', 25)              # festlegen der Schriftart für die Geldanzeige
mausfont = pygame.freetype.SysFont('arial.ttf', 12)      # festlegen der Schriftart für den Gebäudespezifischen Infotext
infotext = pygame.freetype.SysFont('arial.ttf', 15)          # festlegen der Schriftart für den allgemeinen Infotext
infotextb = pygame.freetype.SysFont('arial.ttf', 20, True)   # festlegen der Schriftart für 'infotext' Überschrift
