# externe Libs einbinden, um mehr Feunktionen offen zu haben
import time
import pygame, Einstellungen
pygame.init()

# blocks
class Wald1:
    bild = ["Wald1a.png", "Wald1.png", "Meer.png"] # Liste mit Bildern für Wald1
    pic = pygame.image.load(bild[Einstellungen.Design]) # ausgewähltes Bild
    typ = "Wald" # Typ für spätere Aktionen festlegen
    vkpreis = None # Verkaufspreis festlegen (None = unverkäuflich)
class Wald2:
    bild = ["Wald2a.png", "Wald2.png", "Meer.png"] # siehe Wald1
    pic = pygame.image.load(bild[Einstellungen.Design])
    typ = "Wald"
    vkpreis = None
class Gras:
    preis = 1 # Kaufpreis festlegen
    pic = pygame.image.load("Wiese.png") # Bild festlegen
    typ = "untergrund" # Typ für spätere Aktionen festlegen
    vkpreis = None # Verkaufspreis festlegen (None = unverkäuflich)
    shortcut = '1' # shortcut für schnelle Auswahl festlegen
class Stein:
    preis = 100000
    pic = pygame.image.load("Stein.png")
    typ = "blockade"
    vkpreis = None
    expwr = 1

class PowerBoost:
    def __init__(self):
        self.lasttime = time.time()
        self.pic = pygame.image.load("PwrBoost.png")
        self.animationpart = 0

    typ = "boost"
    vkpreis = 300
    preis = 500

    pic = pygame.image.load("PwrBoost.png")
    pics = ['PwrBoost.png','PwrBoost2.png', 'PwrBoost3.png','PwrBoost4.png']
    animation_del = 0.2

    shortcut = '2'
    group = 0
    expwr = 0.85

""" Erklärungen:
    'def __init__' beinhaltet die Variablen für einzelne, entgültige Gebäude (z.B. der 'eine' Baum bei position (1|1)
        'lasttime' [power, PtE] letzte Bildänderung der Animation
        'animationpart' [power, PtE] aktueller Teil der Animation
    'preis' legt den Preis eines Gebäudes fest
    'vkpreis' legt den Verkaufspreis für ein zu verkaufendes Gebäude fest; 'None' bedeutet, dass das Gebäude nicht verkauft werden kann
    'typ' legt einen Übergeordneten Typ für Gebäude fest
        'power': produziert Energie
        'PtE': Wandelt Energie in Strom um
        'EtM': Macht Geld aus Strom
        Sonstige: siehe Gebäude
    'pic' legt ein Bild für das Gebäude fest
    'pics' [Power, PtE] enthält Bilder, die von der Animation nacheinander dargestellt werden
    'animation_del' legt den Abstand für Bildwechsel einer Animation fest
    'shortcut' legt eine Taste fest, bei deren Druck das ausgewählte Gebäude zu dem der Taste zugeordneten wechselt
    'expwr' legt die Explosionskraft eines Gebäudes fest
    'group' hat keinerlei Bedeutung
    
    [power]
    'power' legt die Energieproduktion pro Tick fest
    'leben' legt die Leben fest, die das Gebäude stehen bleibt (in Ticks)
    
    [PtE, EtM]
    'maxconvert' legt die maximale Menge an Energie/ Strom fest, die konvertiert wird
    'maxheat' legt den maximalen Überschuss fest, den das Gebäude aufnehmen kann, bevor es explodiert
    'self'
        'convert' wirkliche konvertierte Menge
        'lastconvert' letzte konvertierte Menge
        'heat' überschüssige Menge
        
    """
# powerbuildings
class Windrad:
    def __init__(self):
        self.leben = Windrad.leben
        self.lasttime = time.time()
        self.animationpart = 0

    vkpreis = 0
    preis = 0.5
    power = 0.1
    leben = 6

    typ = "power"
    pic = pygame.image.load("Windrad.png")
    pics = ['Windrad.png','Windrad4.png', 'Windrad2.png','Windrad3.png']
    animation_del = 0.2

    shortcut = 'q'
    expwr = 0.2
class Solar:
    def __init__(self):
        self.preis = Solar.preis
        self.power = Solar.power
        self.leben = Solar.leben
        self.lasttime = time.time()
        self.pic = pygame.image.load("Solar.png")
        self.animationpart = 0

    vkpreis = 0
    preis = 8
    power = 0.4
    leben = 25

    typ = "power"
    pic = pygame.image.load("Solar.png")
    pics = ['Solar.png']
    animation_del = 1

    shortcut = 'w'
    group = 1
    expwr = 0.3
class Biogasanlage:
    def __init__(self):
        self.leben = Biogasanlage.leben
        self.lasttime = time.time()
        self.pic = pygame.image.load("Solar.png")
        self.animationpart = 0

    typ = "power"
    vkpreis = 0
    pic = pygame.image.load("Biogas1.png")
    pics = ['Biogas1.png', 'Biogas2.png', 'Biogas3.png', 'Biogas2.png']
    animation_del = 1

    preis = 30
    power = 1
    leben = 40
    shortcut = 'e'
    group = 1
    expwr = 0.3
class Wasserkraftwerk:
    def __init__(self):
        self.preis = Wasserkraftwerk.preis
        self.power = Wasserkraftwerk.power
        self.leben = Wasserkraftwerk.leben
        self.lasttime = time.time()
        self.pic = pygame.image.load("Wasserwerk.png")
        self.animationpart = 0

    typ = "power"
    vkpreis = 0
    pic = pygame.image.load("Wasserwerk.png")
    pics = ['Wasserwerk.png', 'Wasserwerk2.png']
    animation_del = 1

    preis = 280
    power = 4
    leben = 100
    shortcut = 'r'
    group = 1
    expwr = 0.4
class Kohle:
    def __init__(self):
        self.preis = Kohle.preis
        self.power = Kohle.power
        self.leben = Kohle.leben
        self.lasttime = time.time()
        self.pic = pygame.image.load("Kohlekraftwerk.png")
        self.animationpart = 0

    typ = "power"
    vkpreis = 0
    pic = pygame.image.load("Kohlekraftwerk.png")
    pics = ['Kohlekraftwerk.png', 'Kohlekraftwerk2.png', 'Kohlekraftwerk3.png']
    animation_del = 0.3

    preis = 1800
    power = 15
    leben = 180
    shortcut = 't'
    group = 1
    expwr = 0.6
class Atom:
    def __init__(self):
        self.preis = Atom.preis
        self.power = Atom.power
        self.leben = Atom.leben
        self.lasttime = time.time()
        self.pic = pygame.image.load("Atom.png")
        self.animationpart = 0

    typ = "power"
    vkpreis = 0
    pic = pygame.image.load("Atom.png")
    pics = ['Atom.png', 'Atom2.png','Atom3.png','Atom2.png']
    animation_del = 0.8

    preis = 19000
    power = 60
    leben = 500
    shortcut = 'z'
    group = 1
    expwr = 0.8
class Antimateriekraftwerk:
    def __init__(self):
        self.preis = Antimateriekraftwerk.preis
        self.power = Antimateriekraftwerk.power
        self.leben = Antimateriekraftwerk.leben
        self.lasttime = time.time()
        self.pic = pygame.image.load("Dunkle Materie Kraftwerk.png")
        self.animationpart = 0

    typ = "power"
    vkpreis = 0
    pic = pygame.image.load("Dunkle Materie Kraftwerk.png")
    pics = ["Dunkle Materie Kraftwerk.png",'Anti2.png']
    animation_del = 1.2

    preis = 250000
    power = 400
    leben = 1000
    shortcut = 'u'
    group = 1
    expwr = 0.95
class SchwarzesLoch:
    def __init__(self):
        self.preis = SchwarzesLoch.preis
        self.power = SchwarzesLoch.power
        self.leben = SchwarzesLoch.leben
        self.lasttime = time.time()
        self.pic = pygame.image.load("SL1.png")
        self.animationpart = 0

    typ = "power"
    vkpreis = 0
    pic = pygame.image.load("SL1.png")
    pics = ["SL1.png",'SL2.png', 'SL3.png']
    animation_del = 0.1

    preis = 2400000
    power = 2000
    leben = 2000
    shortcut = 'i'
    group = 1
    expwr = 1

# Power => Strom
class Dynamo:
    def __init__(self):
        self.convert = 0
        self.lastconvert = 0
        self.heat = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load("Dynamo.png")
        self.animationpart = 0

    typ = "PtE"
    vkpreis = 0.4
    pic = pygame.image.load("Dynamo.png")
    pics = ['Dynamo.png']
    animation_del = 2
    preis = 0.5
    maxconvert = 0.1
    maxheat = 1
    shortcut = 'a'
    expwr = 0.1
class Generator1:
    def __init__(self):
        self.convert = 0
        self.lastconvert = 0
        self.heat = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load("Generator1.png")
        self.animationpart = 0

    typ = "PtE"
    vkpreis = 16
    pic = pygame.image.load("Generator1.png")
    pics = ['Generator1.png','Generator1b.png']
    animation_del = 0.5

    preis = 20
    maxconvert = 0.4
    maxheat = 4
    shortcut = 's'
    group = 2
    expwr = 0.3
class Generator2:
    def __init__(self):
        self.convert = 0
        self.lastconvert = 0
        self.heat = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load("Generator2.png")
        self.animationpart = 0

    typ = "PtE"
    vkpreis = 40
    pic = pygame.image.load("Generator2.png")
    pics = ['Generator2.png','Generator2b.png']
    animation_del = 0.5

    preis = 50
    maxconvert = 1
    maxheat = 10
    shortcut = 'd'
    group = 2
    expwr = 0.35
class Generator3:
    def __init__(self):
        self.convert = 0
        self.lastconvert = 0
        self.heat = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load("Generator3.png")
        self.animationpart = 0

    typ = "PtE"
    vkpreis = 480
    pic = pygame.image.load("Generator3.png")
    pics = ['Generator3.png','Generator3b.png']
    animation_del = 0.5

    preis = 600
    maxconvert = 4
    maxheat = 40
    shortcut = 'f'
    group = 2
    expwr = 0.4
class Turbine1:
    def __init__(self):
        self.convert = 0
        self.lastconvert = 0
        self.heat = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load("Turbine1.png")
        self.animationpart = 0

    typ = "PtE"
    vkpreis = 3200
    pic = pygame.image.load("Turbine1.png")
    pics = ['Turbine1.png','Turbine1b.png']
    animation_del = 0.5

    preis = 4000
    maxconvert = 16
    maxheat = 160
    shortcut = 'g'
    group = 2
    expwr = 0.5
class Turbine2:
    def __init__(self):
        self.convert = 0
        self.lastconvert = 0
        self.heat = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load("Turbine2.png")
        self.animationpart = 0

    typ = "PtE"
    vkpreis = 32000
    pic = pygame.image.load("Turbine2.png")
    pics = ['Turbine2.png','Turbine2b.png']
    animation_del = 0.5

    preis = 40000
    maxconvert = 60
    maxheat = 600
    shortcut = 'h'
    group = 2
    expwr = 0.6
class Turbine3:
    def __init__(self):
        self.convert = 0
        self.lastconvert = 0
        self.heat = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load("Turbine3.png")
        self.animationpart = 0

    typ = "PtE"
    vkpreis = 400000
    pic = pygame.image.load("Turbine3.png")
    pics = ['Turbine3.png','Turbine3b.png']
    animation_del = 0.5

    preis = 500000
    maxconvert = 400
    maxheat = 4000
    shortcut = 'j'
    group = 2
    expwr = 0.7
class HyperTurbine:
    def __init__(self):
        self.convert = 0
        self.lastconvert = 0
        self.heat = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load('HT1.png')
        self.animationpart = 0

    typ = "PtE"
    vkpreis = 4000000
    pic = pygame.image.load('HT1.png')
    pics = ['HT1.png','HT4.png','HT2.png','HT3.png']
    animation_del = 0.1

    preis = 5000000
    maxconvert = 2000
    maxheat = 20000
    shortcut = 'k'
    group = 2
    expwr = 0.85

# Strom => €
class Stromzaehler:
    def __init__(self):
        self.convert = 0
        self.heat = 0
        self.lastconvert = 0

    typ = "EtM"
    vkpreis = 0.4
    pic = pygame.image.load("Stromzähler.png")
    preis = 0.5
    maxconvert = 0.1
    maxheat = 1
    shortcut = 'y'
    group = 3
    expwr = 0.1
class Haus1:
    def __init__(self):
        self.convert = 0
        self.heat = 0
        self.lastconvert = 0

    typ = "EtM"
    vkpreis = 16
    pic = pygame.image.load("Haus1.png")
    preis = 20
    maxconvert = 0.4
    maxheat = 4
    shortcut = 'x'
    group = 3
    expwr = 0.3
class Haus2:
    def __init__(self):
        self.convert = 0
        self.heat = 0
        self.lastconvert = 0

    typ = "EtM"
    vkpreis = 40
    pic = pygame.image.load("Haus2.png")
    preis = 50
    maxconvert = 1
    maxheat = 10
    shortcut = 'c'
    group = 3
    expwr = 0.4
class Haus3:
    def __init__(self):
        self.convert = 0
        self.heat = 0
        self.lastconvert = 0

    typ = "EtM"
    vkpreis = 480
    pic = pygame.image.load("Haus3.png")
    preis = 600
    maxconvert = 4
    maxheat = 40
    shortcut = 'v'
    group = 3
    expwr = 0.45
class Fabrik1:
    def __init__(self):
        self.convert = 0
        self.heat = 0
        self.lastconvert = 0

    typ = "EtM"
    vkpreis = 3200
    pic = pygame.image.load("Fabrik1.png")
    preis = 4000
    maxconvert = 16
    maxheat = 160
    shortcut = 'b'
    group = 3
    expwr = 0.55
class Fabrik2:
    def __init__(self):
        self.convert = 0
        self.heat = 0
        self.lastconvert = 0

    typ = "EtM"
    vkpreis = 320000
    pic = pygame.image.load("Fabrik2.png")
    preis = 40000
    maxconvert = 60
    maxheat = 600
    shortcut = 'n'
    group = 3
    expwr = 0.6
class Fabrik3:
    def __init__(self):
        self.convert = 0
        self.heat = 0
        self.lastconvert = 0

    typ = "EtM"
    vkpreis = 400000
    pic = pygame.image.load("Fabrik3.png")
    preis = 500000
    maxconvert = 400
    maxheat = 4000
    shortcut = 'm'
    group = 3
    expwr = 0.7
class Universalwerk:
    def __init__(self):
        self.convert = 0
        self.heat = 0
        self.lastconvert = 0
        self.lasttime = time.time()
        self.pic = pygame.image.load("Universalwerk.png")
        self.animationpart = 0

    typ = "EtM"
    vkpreis = 4000000
    pic = pygame.image.load("Universalwerk.png")
    pics = ['Universalwerk.png', 'Universalwerk2.png', 'Universalwerk3.png']
    animation_del = 0.5

    preis = 500000
    maxconvert = 2000
    maxheat = 20000
    shortcut = ','
    group = 3
    expwr = 0.8

class Explosion:
    def __init__(self, expwr, preis):
        self.lasttime = time.time()
        self.state = 0
        self.pic = pygame.image.load('expl0.png')
        self.expwr = expwr
        self.updated = False
        self.preis = preis
    typ = 'expl'
    vkpreis = None
class Geroell:
    def __init__(self, preis):
        self.vkpreis = -preis/10
        self.preis = preis
        self.starttime = time.time()
    typ = 'geroell'
    pic = pygame.image.load('Geröll.png')
    expwr = 1


# Spielvariablen
class Game:
    chosen_item = Windrad              # gewähltes Gebäude
    money = float(Einstellungen.Money) # Geld des Spielers
    tick = 0                           # Für die Tickabfrage (Gebäude aktualisieren)
    old_tick = 0                       # ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
