"""Hier können die Werte des Spiels angepasst werden,
um die Schwierigkeit und Schnelligkeit des Spielerfolgs anzupassen"""


"""Geld, das der Spieler zu begin hat:"""
Money = 2
# Standard: 2
# Möglich: Kommmazahl oder Ganzzahl >= 1.5


"""Warscheinlichkeit, dass aus Wald-/ Meeresblöcken Steine anstatt Gras werden"""
Steine = 0.1
# Standard: 0.1
# Möglich: Kommazahl oder Ganzzahl zwischen inklusive 0 und 1


"""Hintergrundfarbe"""
BgColor = (0,0,0)
# Standard: (0,0,0)
# Möglich: Tuple, (0<=x<=255, 0<=x<=255, 0<=x<=255)
# !Achtung!: Änderungen können Unleserlichkeit der Anzeigen verursachen


"""Preismultiplikator für Vergrößerungen"""
Gplus = 1.2
# Standard: 1.2
# Möglich: Kommazahl oder Ganzzahl>= 1


"""Infostrich (Leben von Bauwerken)"""
Dicke = 2
# Standard: 2
# Möglich: Ganzzahl zwischen inklusive 0 und 10


"""Ticks pro Sekunde"""
TpS = 1
# Standard: 1
# Möglich: Ganzzahl zwischen inklusive 0 und 100


"""Anzeige des Ausgewählten Kästchens"""
RBreite = 2
# Standard: 2
# Möglich: Ganzzahl zwischen inklusive 0 und 5
RFarbe = (255,255,0)
# Standard: (255,255,0)
# Möglich: Tuple, (0<=x<=255, 0<=x<=255, 0<=x<=255)


"""Design"""
Design = 0
# Standard: 0
# Möglich: Auswahl zwischen 0, 1 und 2


"""Automatisches wiederplatzieren kaputter Erzeuger"""
AutoReplace = False
# Standard: False
# Möglich: Auswahl zwischen True und False
