from FunktionenB import *    # eigene Funktionen einbinden
from Einstellungen import *  # Einstellungen einbinden
running = True               # Spiel pausiert?

# strg+klick für gesamten Text
createforest()                      # Wald / Meer nach Zufallsprinzip generieren
setstartpixels()                    # 4*4 Lichtung / Insel in der Mitte generieren

while True:                         # mainloop
    for event in pygame.event.get():                   # Aktionen auslesen
        if event.type == pygame.QUIT: quit()           # Spiel geschlossen?
        if event.type == pygame.KEYDOWN:               # Taste gedrückt?
            if event.key == 32:
                if running:      running = False; print('game paused')
                else:            running = True; print('returned to game')
            if event.key == 27:  quit()
        if event.type == pygame.locals.MOUSEWHEEL:     # gescrollt?
            if event.y == -1 and FunktionenA.scroll in range(-1420, 1):    FunktionenA.scroll -= 60
            elif event.y == 1 and FunktionenA.scroll in range(-1500, -59): FunktionenA.scroll += 60
    if running:
        screen.fill(BgColor)     # Bildschirm füllen, alte Bilder werden gelöscht
        sell_item()              # Prüfen, ob ein Gebäude verkaut wurde
        update_buildings()       # Prüfen, ob
        #                           a) ein Gebäude explodiert ist
        #                           b) ein Gebäude keine Lebenspunkte mehr hat
        #                          und Power /Strom /Geld übertragen bzw. aktualisieren
        choose_item()            # Prüfen, ob Ausgewähltes Gebäude geändert wurde und ggf. anpassen
        set_item()               # Prüfen, ob ein Gebäude gekauft wurde
        update_animations()      # ggf. Animationen aktualisieren
        extend_expl()            # ggf. Explosioenen ausweiten
        blit_item()              # Gebäude, Wiesen Wälder etc. auf dem Bidschirm darstellen
        set_mousetext()          # Infotext aktualisieren und darstellen
        set_item_money_text()    # Geldanzeige und Information über ausgewähltes Gebäude aktualisieren und darstellen
        pygame.display.flip()    # Bildschirm aktualisieren
        time.sleep(0.01)         # Kurze Pause, die der Spieler nicht bemerkt, die allerdings dem Rechner eine kurze
        #                          Verschnaufpause gibt
    else: time.sleep(0.1)        # falls pausiert: warten
