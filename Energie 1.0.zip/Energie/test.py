"""Reine Testdatei, für das Spiel nicht notwendig und den Spieler nicht interessant"""
