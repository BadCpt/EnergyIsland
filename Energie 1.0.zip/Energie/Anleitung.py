# Dieses Projekt entstand aus einem Schulprojekt. Der Code ist mangelhaft, hat allerdings für die 1 gereicht... ;)
# Bei Bugs oder Verbesserungsvorschlägen gerne melden
# Die Logik hat ein bischen gelitten, ich hoffe, das Spiel ist dennoch spielbar
"""
========================================================================================================================
=======================================================ANLEITUNG========================================================
========================================================================================================================

Platziere Gebäude und verdiene Geld...

Die Gebäude sind in drei Gruppen unterteilt: Produzenten, Umwandler, Verbraucher.

Produzenten produzieren Power.
Umwandler machen diese zu Strom...
Verbraucher geben Geld für den Strom.
Leitungen gibt es (noch) keine.

Der Spieler hat zunächst 2$ und nutzt diese, um die kleinsten Gebäude zu platzieren. Diese bringen Geld, er kann mehr
bauen usw.
Der Rest ergibt sich...

!Hinweise!:
- Zum Spielen die Datei "main" starten
- evtl. müssen externe libs (PyGame) heruntergeladen werden
- Produzenten haben eine bestimmte Menge an Leben (schwarzer Balken) und müssen neu plaziert werden.
- Überhitzt ein Gebäude (roter Balken) explodiert es. Je größer das Gebäude, desto wahrscheinlicher ist es, dass
    umstehende Gebäude auch zerstört werden. Explodierte Gebäude hinterlassen Schrott, der für die Hälfte des
    herkömmlichen Preises verkauft werden muss. Verkauft man ihn nicht, entsteht ein Stein an seiner Stelle
- Das Spiel darf gerne selbstständig erweitert werden o.ä.

VIEL SPASS!!!
"""